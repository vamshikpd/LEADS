###############################################################################
###############################################################################
#
#                              CUSTOM TOKEN
#
#    This object is used to store information about a custom token.
#
###############################################################################
###############################################################################

package Endeca::SolEng::DeploymentTemplate::Installer::CustomToken;

use strict;

use Endeca::SolEng::Util qw(Logger StringUtil);

###############################################################################
#
#    Constructor
#
#    Description
#        Constructor method for the CustomToken object.
sub new
{
    my ($class) = @_;
    
    my $logger = Logger->new();
    $logger->scriptName("CustomToken");
    
    my $self = {
        _logger => $logger,
        _name => undef,
        _validation => undef,
        _promptQuestion => undef,
        _configOption => undef,
        _defaultValue => undef
    };
    
    bless $self, $class;
    return $self;
}

###############################################################################
#
#    Subroutine
#        logger
#
#    Description
#        Getter/setter for the logger field.
#
sub logger 
{
     my ($self, $logger) = @_;
     
     if ($logger)
     {
         $self->{_logger} = $logger;
     }
     
     return $self->{_logger};
}

###############################################################################
#
#    Subroutine
#        name
#
#    Description
#        Getter/setter for the name field.
#
sub name 
{
     my ($self, $name) = @_;
     
     if ($name)
     {
         $self->{_name} = $name;
     }
     
     return $self->{_name};
}

###############################################################################
#
#    Subroutine
#        validation
#
#    Description
#        Getter/setter for the validation field.
#
sub validation 
{
     my ($self, $validation) = @_;
     
     if ($validation)
     {
         $self->{_validation} = $validation;
     }
     
     return $self->{_validation};
}

###############################################################################
#
#    Subroutine
#        promptQuestion
#
#    Description
#        Getter/setter for the promptQuestion field.
#
sub promptQuestion 
{
     my ($self, $promptQuestion) = @_;
     
     if ($promptQuestion)
     {
         $self->{_promptQuestion} = $promptQuestion;
     }
     
     return $self->{_promptQuestion};
}

###############################################################################
#
#    Subroutine
#        configOption
#
#    Description
#        Getter/setter for the configOption field.
#
sub configOption 
{
     my ($self, $configOption) = @_;
     
     if ($configOption)
     {
         $self->{_configOption} = $configOption;
     }
     
     return $self->{_configOption};
}

###############################################################################
#
#    Subroutine
#        defaultValue
#
#    Description
#        Getter/setter for the defaultValue field.
#
sub defaultValue 
{
     my ($self, $defaultValue) = @_;
     
     if ($defaultValue)
     {
         $self->{_defaultValue} = $defaultValue;
     }
     
     return $self->{_defaultValue};
}

1;