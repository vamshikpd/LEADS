###############################################################################
###############################################################################
#
#                                UTILITIES
#
#    This module provides access to utility modules in the Util package.
#
###############################################################################
###############################################################################

package Endeca::SolEng::Util;

use strict;
use Endeca::SolEng::Util::Logger;
use Endeca::SolEng::Util::StringUtil;

require Exporter;
our @ISA = qw(Exporter);

use constant Logger => 'Endeca::SolEng::Util::Logger';
use constant StringUtil => 'Endeca::SolEng::Util::StringUtil';

our @EXPORT_OK =
(
    qw(Logger StringUtil)
);

1;