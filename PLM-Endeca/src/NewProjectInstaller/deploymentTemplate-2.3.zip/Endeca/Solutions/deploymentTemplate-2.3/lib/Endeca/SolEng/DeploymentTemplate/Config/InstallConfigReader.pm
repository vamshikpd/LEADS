###############################################################################
###############################################################################
#
#                           INSTALL CONFIG READER
#
#    This module reads and parses configuration for the deployment template
#    install configuration.
#
###############################################################################
###############################################################################

package Endeca::SolEng::DeploymentTemplate::Config::InstallConfigReader;

use strict;

use Endeca::SolEng::DeploymentTemplate::Config::Constants 
    qw(DGRAPH_CI_APP_DESCRIPTOR DGRAPH_EAC_PERL_APP_DESCRIPTOR CONTROLLER_EAC_PERL 
    CONTROLLER_EAC_JAVA DGRAPH_EAC_JAVA_APP_DESCRIPTOR 
    CONTROLLER_JCD AGRAPH_CI_APP_DESCRIPTOR AGRAPH_PARALLEL_FORGE_CI_APP_DESCRIPTOR
    AGRAPH_EAC_JAVA_APP_DESCRIPTOR AGRAPH_PARALLEL_FORGE_EAC_JAVA_APP_DESCRIPTOR);
use Endeca::SolEng::Util qw(Logger StringUtil);
use XML::DOM::Lite qw(Parser);
use XML::DOM::Lite::Constants qw(ELEMENT_NODE TEXT_NODE);

use constant
{
   TAGNAME_INSTALL            => "install",
   TAGNAME_DEPLOYMENT_PATH    => "deployment-path",
   TAGNAME_BASE_MODULE        => "base-module",
   TAGNAME_ADDITIONAL_MODULE  => "additional-module",
   TAGNAME_OPTION             => "option",
   ATTRIBUTE_TYPE             => "type",
   ATTRIBUTE_CONTROLLER       => "controller",
   ATTRIBUTE_APP_NAME         => "app-name",
   ATTRIBUTE_NAME             => "name",
   OPTION_NAME_JCD_PORT       => "jcd-port",
   OPTION_NAME_EAC_PORT       => "eac-port",
   OPTION_NAME_PARALLEL_FORGE => "parallel-forge",
   MODULE_TYPE_CUSTOM         => "custom",
   MODULE_TYPE_DGRAPH         => "dgraph",
   MODULE_TYPE_AGRAPH         => "agraph",
};

###############################################################################
#
#    Constructor
#
#    Description
#        Constructor method for the InstallConfigReader object. Initializes 
#        field values and creates a class logger.
sub new
{
    my ($class, $fileName) = @_;
    
    my $logger = Logger->new();
    $logger->scriptName("InstallConfigReader");
    
    my $self = {
        _logger => $logger,
        _fileName => $fileName,
        _parsedFileDom => undef
    };
    
    bless $self, $class;
    return $self;
}

###############################################################################
#
#    Subroutine
#        fileName
#
#    Description
#        Getter/setter for the file name field. Resets the DOM, to allow re-use
#        of this object by re-setting the file name.
#
sub fileName
{
     my ($self, $fileName) = @_;
     
     if ($fileName)
     {
         $self->{_fileName} = $fileName;
         $self->{_parsedFileDom} = undef;
     }
     
     return $self->{_fileName};
}

###############################################################################
#
#    Subroutine
#        logger
#
#    Description
#        Getter/setter for the logger field.
#
sub logger 
{
     my ($self, $logger) = @_;
     
     if ($logger)
     {
         $self->{_logger} = $logger;
     }
     
     return $self->{_logger};
}

###############################################################################
#
#    Subroutine
#        parsedFileDom
#
#    Description
#        Getter/setter for the parsed file DOM field.
#
sub parsedFileDom 
{
     my ($self, $dom) = @_;
     
     if ($dom)
     {
         $self->{_parsedFileDom} = $dom;
     }
     
     return $self->{_parsedFileDom};
}

###############################################################################
#
#    Subroutine
#        getController
#
#    Description
#        Retrieves the controller type from the deployment config file.
#
sub getController
{
    my ($self) = @_;
    
    my $ret;
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
        my $installList = $dom->getElementsByTagName(TAGNAME_INSTALL);
        if ($installList->length > 0)
        {
            my $installNode = $installList->item(0);
            
            $ret = $installNode->getAttribute(ATTRIBUTE_CONTROLLER);
        }
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        getAppName
#
#    Description
#        Retrieves the application name from the deployment config file.
#
sub getAppName
{
    my ($self) = @_;
    
    my $ret;
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
        my $installList = $dom->getElementsByTagName(TAGNAME_INSTALL);
        if ($installList->length > 0)
        {
            my $installNode = $installList->item(0);
            
            $ret = $installNode->getAttribute(ATTRIBUTE_APP_NAME);
        }
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        getDeploymentPath
#
#    Description
#        Retrieves the deployment path from the deployment config file.
#
sub getDeploymentPath
{
    my ($self) = @_;
    
    return $self->getElementValue(TAGNAME_DEPLOYMENT_PATH);
}

###############################################################################
#
#    Subroutine
#        getBaseModuleDescriptorPath
#
#    Description
#        Retrieves the applicaton descriptor path for the base module from the
#        install config document.
#
sub getBaseModuleDescriptorPath
{
    my ($self) = @_;
    
    my $ret;
    my $logger = $self->logger;
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
        my $baseModuleList = $dom->getElementsByTagName(TAGNAME_BASE_MODULE);
        if ($baseModuleList->length > 0)
        {
            my $baseModuleNode = $baseModuleList->item(0);
            my $stringUtil = StringUtil->new();
            my $moduleType = $stringUtil->trimWhitespace($baseModuleNode->getAttribute(ATTRIBUTE_TYPE));
            
            if ($moduleType)
            {
                # log an error if more than one base module found
                if ($baseModuleList->length > 1)
                {
                    $logger->traceWarn("Found multiple " . TAGNAME_BASE_MODULE . " elements in file " . 
                        $self->fileName . ". Using the first one found, of type " . $moduleType);
                }
                
                my $controller = $self->getController;
                if ($controller eq CONTROLLER_JCD)
                {
                    if ($moduleType eq MODULE_TYPE_DGRAPH)
                    {
                        $ret = DGRAPH_CI_APP_DESCRIPTOR;
                    }
                    elsif ($moduleType eq MODULE_TYPE_AGRAPH)
                    {
                    	if ($self->isParallelForgeEnabled())
                        {
                            $ret = AGRAPH_PARALLEL_FORGE_CI_APP_DESCRIPTOR;
                        }
                        else
                        {
                            $ret = AGRAPH_CI_APP_DESCRIPTOR;
                        }
                    }
                    else
                    {
                        $logger->traceWarn("Found unknown base module of type $moduleType in file " .
                            $self->fileName);
                    }
                }
                elsif ($controller eq CONTROLLER_EAC_PERL)
                {
                    if ($moduleType eq MODULE_TYPE_DGRAPH)
                    {
                        $ret = DGRAPH_EAC_PERL_APP_DESCRIPTOR;
                    }
                    else
                    {
                        $logger->traceWarn("Found unknown base module of type $moduleType in file " .
                            $self->fileName);
                    }
                }
                elsif ($controller eq CONTROLLER_EAC_JAVA)
                {
                    if ($moduleType eq MODULE_TYPE_DGRAPH)
                    {
                        $ret = DGRAPH_EAC_JAVA_APP_DESCRIPTOR;
                    }
                    elsif ($moduleType eq MODULE_TYPE_AGRAPH)
                    {
                    	if ($self->isParallelForgeEnabled())
                        {
                            $ret = AGRAPH_PARALLEL_FORGE_EAC_JAVA_APP_DESCRIPTOR;
                        }
                        else
                        {
                            $ret = AGRAPH_EAC_JAVA_APP_DESCRIPTOR;
                        }
                    }
                    else
                    {
                        $logger->traceWarn("Found unknown base module of type $moduleType in file " .
                            $self->fileName);
                    }
                }
                else
                {
                    $logger->traceWarn("Found unknown controller type $controller in file " . $self->fileName);
                }
            }
            else
            {
                $logger->traceWarn("Invalid base module found with no type specified in file " .
                    $self->fileName);
            }
        }
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        getAddOnModuleDescriptorPaths
#
#    Description
#        Retrieves a list of module applicaton descriptor paths from the
#        install config document.
#
sub getAddOnModuleDescriptorPaths
{
    my ($self) = @_;
    
    my @ret;
    my $logger = $self->logger;
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
        my $stringUtil = StringUtil->new();
        my $addOnModuleList = $dom->getElementsByTagName(TAGNAME_ADDITIONAL_MODULE);
        for (my $i = 0; $i < $addOnModuleList->length; $i++)
        {
            my $addOnModuleNode = $addOnModuleList->item($i);
            my $type = $stringUtil->trimWhitespace($addOnModuleNode->getAttribute(ATTRIBUTE_TYPE));
            if (! $type)
            {
                $type = MODULE_TYPE_CUSTOM;
            }
            
            if ($type eq MODULE_TYPE_CUSTOM)
            {
                my $textNode = $addOnModuleNode->firstChild;
                if ($textNode && $textNode->nodeType eq TEXT_NODE)
                {
                    my $modulePath = $stringUtil->trimWhitespace($textNode->nodeValue);
                    if ($modulePath)
                    {
                        push(@ret, $modulePath);
                    }
                    else
                    {
                        $logger->traceWarn("Custom module type found in file " . $self->fileName . 
                            " has no app descriptor XML file specified. Ignoring.");
                    }
                }
                else
                {
                    $logger->traceWarn("Custom module type found in file " . $self->fileName . 
                        " has no app descriptor XML file specified. Ignoring.");
                }
            }
            else
            {
                $logger->traceWarn("Found unknown add-on module of type $type in file" .
                    $self->fileName . ". Ignoring.");
            }
        }
    }
    
    return @ret;
}

###############################################################################
#
#    Subroutine
#        getOptionByName
#
#    Description
#        Retrieves the option with the specified name from the install config 
#        file.
#
sub getOptionByName
{
    my ($self, $name) = @_;
    
    my $ret;
    
    my %options = $self->getOptions;
    # Perl requires the () next to the constant name in this context,
    # as the default behavior is to interpret the bareword, instead
    # of resolving the constant
    $ret = $options{ $name };
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        getJcdPort
#
#    Description
#        Retrieves the JCD port from the install config file.
#
sub getJcdPort
{
    my ($self) = @_;
    
    my $ret;
    
    my %options = $self->getOptions;
    # Perl requires the () next to the constant name in this context,
    # as the default behavior is to interpret the bareword, instead
    # of resolving the constant
    $ret = $options{ OPTION_NAME_JCD_PORT() };
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        getEacPort
#
#    Description
#        Retrieves the EAC port from the install config file.
#
sub getEacPort
{
    my ($self) = @_;
    
    my $ret;
    
    my %options = $self->getOptions;
    # Perl requires the () next to the constant name in this context,
    # as the default behavior is to interpret the bareword, instead
    # of resolving the constant
    $ret = $options{ OPTION_NAME_EAC_PORT() };
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        isParallelForgeEnabled
#
#    Description
#        Retrieves the parallel-forge option and returns true (1) if the option
#        is enabled.
#
sub isParallelForgeEnabled
{
    my ($self) = @_;
    
    my $ret = 0;
    
    my %options = $self->getOptions;
    # Perl requires the () next to the constant name in this context,
    # as the default behavior is to interpret the bareword, instead
    # of resolving the constant
    my $value = $options{ OPTION_NAME_PARALLEL_FORGE() };
    
    if ($value =~ /true/i)
    {
    	$ret = 1;
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        getOptions
#
#    Description
#        Retrieves the option values from the deployment config file. Returns
#        a hash, keyed by option name.
#
sub getOptions
{
    my ($self) = @_;
    my %ret;
    
    my $logger = $self->logger;
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
        my $optionList = $dom->getElementsByTagName(TAGNAME_OPTION);
        my $stringUtil = StringUtil->new();
        for (my $i = 0; $i < $optionList->length; $i++)
        {
            my $option = $optionList->item($i);
            my $optionName = $option->getAttribute(ATTRIBUTE_NAME);
            
            if ($optionName)
            {
                my $textNode = $option->firstChild;
                if ($textNode->nodeType eq TEXT_NODE)
                {
                    my $optionValue = $textNode->nodeValue;
                    if ($optionValue)
                    {
                        $ret{$stringUtil->trimWhitespace($optionName)} = $stringUtil->trimWhitespace($optionValue); 
                    }
                }
            }
        }
    }
    
    return %ret;
}

###############################################################################
#
#    Subroutine
#        getElementValue
#
#    Description
#        Retrieves the specified element's text value.
#
sub getElementValue
{
    my ($self, $tagName) = @_;
    my $ret;
    
    my $logger = $self->logger;
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
        my $elementList = $dom->getElementsByTagName($tagName);
        if ($elementList->length > 0)
        {
            my $elementNode = $elementList->item(0);
            my $textNode = $elementNode->firstChild;
            if ($textNode->nodeType eq TEXT_NODE)
            {
                my $stringUtil = StringUtil->new();
                $ret = $stringUtil->trimWhitespace($textNode->nodeValue);
            }
        }
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        parse
#
#    Description
#        Parses the install config file into an in-memory DOM and stores a
#        reference in the object.
#
sub parse
{
    my ($self) = @_;
    
    my $dom;
    my $ret = 0;
    
    my $logger = $self->logger;
    $logger->traceInfo("Parsing install config file " . $self->fileName . ".");

    if (-f $self->fileName)
    {
    	my $parser = Parser->new();
    	$dom = $parser->parseFile($self->fileName);
    	
    	$self->parsedFileDom($dom);
    	$ret = 1;
    }
    else
    {
        $logger->traceError("File " . $self->fileName . " does not exist.");
    }

    return $ret;
}

1;