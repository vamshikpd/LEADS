###############################################################################
###############################################################################
#
#                          APPLICATION DESCRIPTOR READER
#
#    This module reads and parses application descriptor XML files for the
#    deployment template installer.
#
###############################################################################
###############################################################################

package Endeca::SolEng::DeploymentTemplate::Config::AppDescriptorReader;

use strict;

use Endeca::SolEng::Util qw(Logger StringUtil);
use Endeca::SolEng::DeploymentTemplate::Installer::CopyPattern;
use Endeca::SolEng::DeploymentTemplate::Installer::CustomToken;
use Endeca::SolEng::DeploymentTemplate::Config::Constants 
    qw(PLATFORM_WINDOWS PLATFORM_UNIX IAP_460 IAP_470 IAP_480 IAP_500 IAP_510);
use XML::DOM::Lite qw(Parser);
use XML::DOM::Lite::Constants qw(ELEMENT_NODE TEXT_NODE);

# XML element/attribute name constants
use constant
{
   TAGNAME_APP_DESCRIPTOR     => "app-descriptor",
   TAGNAME_CUSTOM_TOKENS      => "custom-tokens",
   TAGNAME_TOKEN              => "token",
   TAGNAME_PROMPT_QUESTION    => "prompt-question",
   TAGNAME_CONFIG_OPTION      => "install-config-option",
   TAGNAME_DEFAULT_VALUE      => "default-value",
   TAGNAME_DIR_STRUCTURE      => "dir-structure",
   TAGNAME_DIR                => "dir",
   TAGNAME_COPY_PATTERN       => "copy-pattern",
   TAGNAME_COPY               => "copy",
   TAGNAME_SRC_DIR            => "src-dir",
   TAGNAME_SRC_FILE           => "src-file",
   TAGNAME_DEST_DIR           => "dest-dir",
   ATTRIBUTE_UPDATE           => "update",
   ATTRIBUTE_ID               => "id",
   ATTRIBUTE_SOURCE_ROOT      => "src-root",
   ATTRIBUTE_NAME             => "name",
   ATTRIBUTE_VALIDATION_TYPE  => "validation",
   ATTRIBUTE_PLATFORM         => "platform",
   ATTRIBUTE_PRIMARY          => "primary",
   ATTRIBUTE_CLEAR_DEST_DIR   => "clear-dest-dir",
   ATTRIBUTE_RECURSIVE        => "recursive",
   ATTRIBUTE_PRESERVE_SUBDIRS => "preserve-subdirs",
   ATTRIBUTE_FILTER_FILES     => "filter-files",
   ATTRIBUTE_MODE             => "mode",
   ATTRIBUTE_ENDECA_VERSION   => "endeca-version",
};

###############################################################################
#
#    Constructor
#
#    Description
#        Constructor method for the InstallConfigReader object. Initializes 
#        field values and creates a class logger.
sub new
{
    my ($class, $fileName) = @_;
    
    my $logger = Logger->new();
    $logger->scriptName("AppDescriptorReader");
    
    my $self = {
        _logger => $logger,
        _fileName => $fileName,
        _parsedFileDom => undef
    };
    
    bless $self, $class;
    return $self;
}

###############################################################################
#
#    Subroutine
#        fileName
#
#    Description
#        Getter/setter for the file name field. Resets the DOM, to allow re-use
#        of this object by re-setting the file name.
#
sub fileName 
{
     my ($self, $fileName) = @_;
     
     if ($fileName)
     {
         $self->{_fileName} = $fileName;
         $self->{_parsedFileDom} = undef;
     }
     
     return $self->{_fileName};
}

###############################################################################
#
#    Subroutine
#        logger
#
#    Description
#        Getter/setter for the logger field.
#
sub logger 
{
     my ($self, $logger) = @_;
     
     if ($logger)
     {
         $self->{_logger} = $logger;
     }
     
     return $self->{_logger};
}

###############################################################################
#
#    Subroutine
#        parsedFileDom
#
#    Description
#        Getter/setter for the parsed file DOM field.
#
sub parsedFileDom 
{
     my ($self, $dom) = @_;
     
     if ($dom)
     {
         $self->{_parsedFileDom} = $dom;
     }
     
     return $self->{_parsedFileDom};
}

###############################################################################
#
#    Subroutine
#        isUpdateInstall
#
#    Description
#        Retrieves the root install element from the install config file and
#        returns true if the update attribute is set to true. If the document 
#        has not yet been parsed, this sub will call the parse subroutine to 
#        bring it into memory.
#
sub isUpdateInstall
{
    my ($self) = @_;
    my $ret = 0;
    
    my $logger = $self->logger;
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
        my $installNodeList = $dom->getElementsByTagName(TAGNAME_APP_DESCRIPTOR);
        if ($installNodeList->length > 0)
        {
            my $installNode = $installNodeList->item(0);
            my $attr = parseTrueFalseAttribute($installNode, ATTRIBUTE_UPDATE);
            if ($attr eq 1)
            {
                $ret = 1;
            }
        }
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        getRootSourceDir
#
#    Description
#        Retrieves the value of the root source directory attribute.
#
sub getRootSourceDir
{
    my ($self) = @_;
    my $ret;
    
    my $logger = $self->logger;
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
        my $copyPatternNodeList = $dom->getElementsByTagName(TAGNAME_COPY_PATTERN);
        if ($copyPatternNodeList->length > 0)
        {
            my $copyPatternNode = $copyPatternNodeList->item(0);
            my $attr = $copyPatternNode->getAttribute(ATTRIBUTE_SOURCE_ROOT);
            if ($attr)
            {
                my $stringUtil = StringUtil->new();
                $ret = $stringUtil->trimWhitespace($attr);
            }
        }
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        getInstallId
#
#    Description
#        Gets the install ID.
#
sub getInstallId
{
    my ($self) = @_;
    my $ret;
    
    my $logger = $self->logger;
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
        my $installNodeList = $dom->getElementsByTagName(TAGNAME_APP_DESCRIPTOR);
        if ($installNodeList->length > 0)
        {
            my $installNode = $installNodeList->item(0);
            my $attr = $installNode->getAttribute(ATTRIBUTE_ID);
            if ($attr)
            {
                my $stringUtil = StringUtil->new();
                $ret = $stringUtil->trimWhitespace($attr);
            }
        }
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        getInstallDirs
#
#    Description
#        Retrieves an array of install directories from the parsed
#        install config files. If the document has not yet been parsed, this
#        sub will call the parse subroutine to bring it into memory.
#
#        If the primary parameter is specified as 0 (false), this sub will return
#        only those directories without the attribute primary="true."
#
#        If $platform is specified, only directories with the associated
#        platform or directories with no platform specification will be 
#        returned. If no platform is specified, all directories are returned.
#
sub getInstallDirs
{
    my ($self, $primary, $platform) = @_;
    
    my @ret;
    my $dirCount = 0;
    
    my $logger = $self->logger;
    
    if ($platform && ! isValidPlatform($platform))
    {
        $logger->traceWarn("Unknown platform '" . $platform . "' requested. Ignoring platform.");
        $platform = undef;
    }
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
        my $installDirs = $dom->getElementsByTagName(TAGNAME_DIR_STRUCTURE);
        for (my $i = 0; $i < $installDirs->length; $i++)
        {
            my $installDirsNode = $installDirs->item($i);
            my $installDirNodeList = $installDirsNode->childNodes;
            for (my $j = 0; $j < $installDirNodeList->length; $j++)
            {
                my $installDirNode = $installDirNodeList->item($j);
                if ($installDirNode->nodeType eq ELEMENT_NODE && $installDirNode->tagName eq TAGNAME_DIR)
                {
                    my $installDirTextNode = $installDirNode->firstChild;
                    if ($installDirTextNode && $installDirTextNode->nodeType eq TEXT_NODE)
                    {
                        my $installDir = $installDirTextNode->nodeValue;
                        my $stringUtil = StringUtil->new();
                        
                        my $skip = 0;
                        
                        # If a child install has been requested, skip directories marked
                        # as being primary="true"
                        if (! $primary)
                        {
                            my $primaryAttr = $installDirNode->getAttribute(ATTRIBUTE_PRIMARY);
                            if ($primaryAttr)
                            {
                                if ($stringUtil->trimWhitespace($primaryAttr) =~ /true/i)
                                {
                                    $skip = 1;
                                } 
                            }
                        }
                        
                        # If a platform has been requested, skip directories marked with
                        # a platform other than the one requested.
                        if ($platform)
                        {
                            my $platformAttr = $installDirNode->getAttribute(ATTRIBUTE_PLATFORM);
                            if ($platformAttr)
                            {
                                if ($stringUtil->trimWhitespace($platformAttr) ne $platform)
                                {
                                    $skip = 1;
                                }
                            }
                        }
                        
                        if (! $skip)
                        {
                            $ret[$dirCount++] = $stringUtil->trimWhitespace($installDir);
                        }
                    }
                }
            }
        }
    }
    
    return @ret;
}

###############################################################################
#
#    Subroutine
#        getCopyPatterns
#
#    Description
#        Retrieves an array of CopyPattern objects, containing copy information
#        from the parsed install config files. If the document has not yet been 
#        parsed, this sub will call the parse subroutine to bring it into 
#        memory.
#
#        If the primary parameter is specified as 0 (false), this sub will return
#        only those copies without the attribute primary="true."
#
#        If a platform is specified, only copies with the associated
#        platform or copies with no platform specification will be 
#        returned. If no platform is specified, all copies are returned.
#
#        If an IAP version is specified, only copies with the associated version
#        number or copies with no version specififed will be returned.
#        If no version is specified, all copies are returned.
#
sub getCopyPatterns
{
    my ($self, $primary, $platform, $endecaVersion) = @_;
    
    my @ret;
    my $copyCount = 0;
    
    my $logger = $self->logger;
    
    if ($platform && ! isValidPlatform($platform))
    {
        $logger->traceWarn("Unknown platform '" . $platform . "' requested. Ignoring platform.");
        $platform = undef;
    }
    
    if ($endecaVersion && ! isValidEndecaVersion($endecaVersion))
    {
        $logger->traceWarn("Unknown Endeca version '" . $endecaVersion . "' requested. Ignoring version.");
        $endecaVersion = undef;
    }
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
        my $copyPatterns = $dom->getElementsByTagName(TAGNAME_COPY_PATTERN);
        for (my $i = 0; $i < $copyPatterns->length; $i++)
        {
            my $copyPatternsNode = $copyPatterns->item($i);
            my $copyNodeList = $copyPatternsNode->childNodes;
            for (my $j = 0; $j < $copyNodeList->length; $j++)
            {
                my $copyNode = $copyNodeList->item($j);
                if ($copyNode->nodeType eq ELEMENT_NODE && $copyNode->tagName eq TAGNAME_COPY)
                {
                    # initialize copy pattern object
                    my $copyPattern = Endeca::SolEng::DeploymentTemplate::Installer::CopyPattern->new();
                    
                    # initialize string utility to assist with parsing
                    my $stringUtil = StringUtil->new();
                 
                    # retrieve attributes
                    foreach my $attrName (ATTRIBUTE_CLEAR_DEST_DIR, ATTRIBUTE_RECURSIVE, ATTRIBUTE_PRESERVE_SUBDIRS,
                                          ATTRIBUTE_FILTER_FILES, ATTRIBUTE_PRIMARY)
                    {
                        my $attr = parseTrueFalseAttribute($copyNode, $attrName);
                        if ($attr > -1)
                        {
                            if ($attrName eq ATTRIBUTE_CLEAR_DEST_DIR)
                            {
                                $copyPattern->clearDestDir($attr);
                            }
                            elsif ($attrName eq ATTRIBUTE_RECURSIVE) 
                            {
                                $copyPattern->recursive($attr);
                            }
                            elsif ($attrName eq ATTRIBUTE_PRESERVE_SUBDIRS) 
                            {
                                $copyPattern->preserveSubDirs($attr);
                            }
                            elsif ($attrName eq ATTRIBUTE_FILTER_FILES) 
                            {
                                $copyPattern->filterFiles($attr);
                            }
                            elsif ($attrName eq ATTRIBUTE_PRIMARY) 
                            {
                                $copyPattern->primary($attr);
                            }
                        }
                    }
                    
                    my $platformAttr = $copyNode->getAttribute(ATTRIBUTE_PLATFORM);
                    if ($platformAttr)
                    {
                        $copyPattern->platform($stringUtil->trimWhitespace($platformAttr));
                    }
                    
                    my $endecaVersionAttr = $copyNode->getAttribute(ATTRIBUTE_ENDECA_VERSION);
                    if ($endecaVersionAttr)
                    {
                        $copyPattern->endecaVersion($stringUtil->trimWhitespace($endecaVersionAttr));
                    }
                    
                    my $modeAttr = $copyNode->getAttribute(ATTRIBUTE_MODE);
                    if ($modeAttr)
                    {
                        $copyPattern->mode($stringUtil->trimWhitespace($modeAttr));
                    }
                    
                    # retrieve src dir/file and dest dir element values
                    my $copyChildNodes = $copyNode->childNodes;
                    for (my $k = 0; $k < $copyChildNodes->length; $k++)
                    {
                        my $node = $copyChildNodes->item($k);
                        if ($node->nodeType eq ELEMENT_NODE && ($node->tagName eq TAGNAME_SRC_DIR ||
                            $node->tagName eq TAGNAME_SRC_FILE || $node->tagName eq TAGNAME_DEST_DIR))
                        {
                            my $textNode = $node->firstChild;
                            if ($textNode && $textNode->nodeType eq TEXT_NODE)
                            {
                                my $value = $textNode->nodeValue;
                                
                                if ($node->tagName eq TAGNAME_SRC_DIR)
                                {
                                    $copyPattern->srcDir($stringUtil->trimWhitespace($value));
                                }
                                elsif ($node->tagName eq TAGNAME_SRC_FILE)
                                {
                                    $copyPattern->srcFile($stringUtil->trimWhitespace($value));
                                }
                                elsif ($node->tagName eq TAGNAME_DEST_DIR)
                                {
                                    $copyPattern->destDir($stringUtil->trimWhitespace($value));
                                }
                            }
                        }
                    }

                    my $skip = 0;
                        
                    # If a child install has been requested, skip copies marked
                    # as being primary="true"
                    if (! $primary && $copyPattern->primary)
                    {
                        $skip = 1;
                    }
                     
                    # If a platform has been requested, skip directories marked with
                    # a platform other than the one requested.
                    if ($platform && $copyPattern->platform && $copyPattern->platform ne $platform)
                    {
                        $skip = 1;
                    }
                    
                    # If an Endeca version has been requested, skip directories marked with
                    # a version other than the one requested.
                    if ($endecaVersion && $copyPattern->endecaVersion && $copyPattern->endecaVersion ne $endecaVersion)
                    {
                        $skip = 1;
                    }
                                            
                    if (! $skip)
                    {                        
                        $ret[$copyCount++] = $copyPattern;
                    }
                }
            }
        }
    }
    
    return @ret;
}

###############################################################################
#
#    Subroutine
#        getCustomTokens
#
#    Description
#        Retrieves an array of CustomTokens
#
sub getCustomTokens
{
    my ($self) = @_;
    
    my @ret;
    my $tokenCount = 0;
    
    my $logger = $self->logger;
    
    # If the config file has not yet been parsed, parse it
    my $dom = $self->parsedFileDom;
    if (! $dom)
    {
        $self->parse;
        $dom = $self->parsedFileDom;
    }
    
    # If the config DOM is still unavailable, the parser failed.
    if ($dom)
    {
    	my $customTokens = $dom->getElementsByTagName(TAGNAME_CUSTOM_TOKENS);
        for (my $i = 0; $i < $customTokens->length; $i++)
        {
        	my $customTokensNode = $customTokens->item($i);
        	my $customTokenNodeList = $customTokensNode->childNodes;
            for (my $j = 0; $j < $customTokenNodeList->length; $j++)
            {
            	my $customTokenNode = $customTokenNodeList->item($j);
                if ($customTokenNode->nodeType eq ELEMENT_NODE && $customTokenNode->tagName eq TAGNAME_TOKEN)
                {
                    # initialize custom token object
                    my $customToken = Endeca::SolEng::DeploymentTemplate::Installer::CustomToken->new();
                    
                    # initialize string utility to assist with parsing
                    my $stringUtil = StringUtil->new();
                 
                    # retrieve attributes
                    my $nameAttr = $customTokenNode->getAttribute(ATTRIBUTE_NAME);
                    if ($nameAttr)
                    {
                        $customToken->name($stringUtil->trimWhitespace($nameAttr));
                    }
                    
                    my $validationType = $customTokenNode->getAttribute(ATTRIBUTE_VALIDATION_TYPE);
                    if ($validationType)
                    {
                        $customToken->validation($stringUtil->trimWhitespace($validationType));
                    }
                    
                    # retrieve prompt question and config option name element values
                    my $tokenChildNodes = $customTokenNode->childNodes;
                    for (my $k = 0; $k < $tokenChildNodes->length; $k++)
                    {
                        my $node = $tokenChildNodes->item($k);
                        if ($node->nodeType eq ELEMENT_NODE && ($node->tagName eq TAGNAME_PROMPT_QUESTION ||
                            $node->tagName eq TAGNAME_CONFIG_OPTION || $node->tagName eq TAGNAME_DEFAULT_VALUE))
                        {
                            my $textNode = $node->firstChild;
                            if ($textNode && $textNode->nodeType eq TEXT_NODE)
                            {
                                my $value = $textNode->nodeValue;
                                
                                if ($node->tagName eq TAGNAME_PROMPT_QUESTION)
                                {
                                    $customToken->promptQuestion($stringUtil->trimWhitespace($value));
                                }
                                elsif ($node->tagName eq TAGNAME_CONFIG_OPTION)
                                {
                                    $customToken->configOption($stringUtil->trimWhitespace($value));
                                }
                                elsif ($node->tagName eq TAGNAME_DEFAULT_VALUE)
                                {
                                    $customToken->defaultValue($stringUtil->trimWhitespace($value));
                                }
                            }
                        }
                    }
                    
                    $ret[$tokenCount++] = $customToken;
                }
            }
        }
    }
    
    return @ret;
}

###############################################################################
#
#    Subroutine
#        parseTrueFalseAttribute
#
#    Description
#        Retrieves an attribute value from a node and parses a true/false
#        value from it.
#
#    Returns
#        -1  if the attribute does not exist
#         0  if the attribute value is false
#         1  if the attribute value is true
#
sub parseTrueFalseAttribute
{
    my ($node, $attrName) = @_;
    
    my $ret = -1;
    
    if ($node && $attrName)
    {
        my $attrValue = $node->getAttribute($attrName);
        if ($attrValue)
        {
            my $stringUtil = StringUtil->new();
            if ($stringUtil->trimWhitespace($attrValue) =~ /true/i)
            {
                $ret = 1;
            }
            else
            {
                $ret = 0;
            } 
        }
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        isValidPlatform
#
#    Description
#        Validates the specified platform and returns 1 (true) if it is a
#        known platform.
#
sub isValidPlatform
{
    my ($platform) = @_;
    
    my $ret = 0;
    
    if ($platform && ($platform eq PLATFORM_WINDOWS || $platform eq PLATFORM_UNIX))
    {
        $ret = 1;
    }

    return $ret;
}

###############################################################################
#
#    Subroutine
#        isValidEndecaVersion
#
#    Description
#        Validates the specified IAP version and returns 1 (true) if it is a
#        known platform.
#
sub isValidEndecaVersion
{
    my ($endecaVersion) = @_;
    
    my $ret = 0;
    
    if ($endecaVersion && ($endecaVersion eq IAP_460 || $endecaVersion eq IAP_470 ||
    $endecaVersion eq IAP_480 || $endecaVersion eq IAP_500 || $endecaVersion eq IAP_510))
    {
        $ret = 1;
    }

    return $ret;
}

###############################################################################
#
#    Subroutine
#        parse
#
#    Description
#        Parses the install config file into an in-memory DOM and stores a
#        reference in the object.
#
sub parse
{
    my ($self) = @_;
    
    my $dom;
    my $ret = 0;
    
    my $logger = $self->logger;
    $logger->traceInfo("Parsing application descriptor file " . $self->fileName . ".");

    if (-f $self->fileName)
    {
    	my $parser = Parser->new();
    	$dom = $parser->parseFile($self->fileName);
    	
    	$self->parsedFileDom($dom);
    	$ret = 1;
    }
    else
    {
        $logger->traceError("File " . $self->fileName . " does not exist.");
    }

    return $ret;
}

1;