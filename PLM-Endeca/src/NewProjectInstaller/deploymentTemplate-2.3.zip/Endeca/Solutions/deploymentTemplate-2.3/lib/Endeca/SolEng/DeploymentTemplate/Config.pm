###############################################################################
###############################################################################
#
#                                CONFIG
#
#    This module provides access to config handler modules in the Config 
#    package.
#
###############################################################################
###############################################################################

package Endeca::SolEng::DeploymentTemplate::Config;

use strict;
use Endeca::SolEng::DeploymentTemplate::Config::InstallConfigReader;
use Endeca::SolEng::DeploymentTemplate::Config::AppDescriptorReader;
use Endeca::SolEng::DeploymentTemplate::Config::Constants  
    qw(PLATFORM_WINDOWS PLATFORM_UNIX IAP_460 IAP_470 IAP_480 IAP_500 IAP_510
        DGRAPH_CI_APP_DESCRIPTOR DGRAPH_EAC_PERL_APP_DESCRIPTOR 
        AGRAPH_CI_APP_DESCRIPTOR AGRAPH_PARALLEL_FORGE_CI_APP_DESCRIPTOR 
        DGRAPH_EAC_JAVA_APP_DESCRIPTOR AGRAPH_EAC_JAVA_APP_DESCRIPTOR 
        AGRAPH_PARALLEL_FORGE_EAC_JAVA_APP_DESCRIPTOR CONTROLLER_EAC_JAVA 
        CONTROLLER_EAC_PERL CONTROLLER_JCD);

require Exporter;
our @ISA = qw(Exporter);

use constant InstallConfigReader    => "Endeca::SolEng::DeploymentTemplate::Config::InstallConfigReader";
use constant AppDescriptorReader    => "Endeca::SolEng::DeploymentTemplate::Config::AppDescriptorReader";
use constant Constants              => "Endeca::SolEng::DeploymentTemplate::Config::Constants";

our @EXPORT_OK =
(
    @Endeca::SolEng::DeploymentTemplate::Config::Constants::EXPORT_OK,
    qw(InstallConfigReader AppDescriptorReader Constants)
);

1;