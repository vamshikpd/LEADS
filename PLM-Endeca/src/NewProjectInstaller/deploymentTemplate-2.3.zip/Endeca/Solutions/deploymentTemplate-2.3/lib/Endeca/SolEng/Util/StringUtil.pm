###############################################################################
###############################################################################
#
#                                 STRINGUTIL
#
#    This module exposes string manipulation subroutines.
#
###############################################################################
###############################################################################

package Endeca::SolEng::Util::StringUtil;

use strict;

use constant CHARS_PER_LINE => 80;

###############################################################################
#
#    Constructor
#
#    Description
#        Constructor method for the StringUtil object. Initializes string, if
#        specified.
sub new
{
    my ($class, $string) = @_;
    my $self = {
        _string => $string
    };
    
    bless $self, $class;
    return $self;
}

###############################################################################
#
#    Subroutine
#        string
#
#    Description
#        Getter/setter for the string field.
#
sub string 
{
     my ($self, $string) = @_;
     
     if ($string)
     {
         $self->{_string} = $string;
     }
     
     return $self->{_string};
}

###############################################################################
#
#    Subroutine
#        trimWhitespace
#
#    Description
#        Removes the whitespace from the beginning and end of a string.
#
sub trimWhitespace 
{
    my ($self, $str) = @_;
    
    if (! $str)
    {
        $str = $self->string;
    }
    
    my $ret = $str;
    
    if ($ret)
    {
        $ret =~ s/^\s+//;
        $ret =~ s/\s+$//;
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        fitToScreen
#
#    Description
#        Formats the string to include line breaks so that the string displays
#        cleanly on the limited screen width of a terminal window.
#
sub fitToScreen
{
    my ($self, $str) = @_;
    
    if (! $str)
    {
        $str = $self->string;
    }
    
    my $ret = $str;
    
    if (length($str) > CHARS_PER_LINE)
    {
        $ret = "";
        my @lines = split(/(\n+)/, $str);
        for (my $i = 0; $i < scalar(@lines); $i++)
        {
           my $line = $lines[$i];
           if ($line =~ /^\n+$/)
           {
               $ret .= $line . "   ";
           }
           elsif (length($line) <= CHARS_PER_LINE)
           {
               $ret .= $line;
           }
           else
           {
               my @words = split(/(\s+)/, $line);
               my $lengthSoFar = 0;
               
               # if this is not the first line, it's indented
               if ($i != 0)
               {
                   $lengthSoFar = 3;
               }
               my $lineSoFar = "";
               foreach my $word (@words)
               {
                   if ($word =~ /^\s+$/)
                   {
                       if (($lengthSoFar + length($word)) >= CHARS_PER_LINE)
                       {
                           $lineSoFar .= "\n   ";
                           $lengthSoFar = 3;
                       }
                       else
                       {
                           $lineSoFar .= $word;
                           $lengthSoFar += length($word);
                       }
                   }
                   else
                   {
                       if (($lengthSoFar + length($word)) > CHARS_PER_LINE)
                       {
                           $lineSoFar .= "\n   " . $word;
                           $lengthSoFar = length($word) + 3;
                       }
                       else
                       {
                           $lineSoFar .= $word;
                           $lengthSoFar += length($word);
                       }
                   }
               }
               
               $ret .= $lineSoFar;
           }
        }
    }
    else
    {
        $ret =~ s/(\n+)/$1   /;
    }
    
    return $ret;
}

1;