###############################################################################
###############################################################################
#
#                             INPUT HELPER
#
#    This object exposes sbroutines used to handle and validate user input.
#
###############################################################################
###############################################################################

package Endeca::SolEng::DeploymentTemplate::Installer::InputHelper;

use strict;

use Endeca::SolEng::Util qw(Logger StringUtil);

###############################################################################
#
#    Constructor
#
#    Description
#        Constructor method for the CopyPattern object.
sub new
{
    my ($class) = @_;
    
    my $logger = Logger->new();
    $logger->scriptName("InputHelper");
    
    my $self = {
        _logger => $logger,
    };
    
    bless $self, $class;
    return $self;
}

###############################################################################
#
#    Subroutine
#        logger
#
#    Description
#        Getter/setter for the logger field.
#
sub logger 
{
     my ($self, $logger) = @_;
     
     if ($logger)
     {
         $self->{_logger} = $logger;
     }
     
     return $self->{_logger};
}

###############################################################################
#
#    Subroutine
#        prompt
#
#    Description
#        Displays message to prompt user.
#
sub prompt 
{
    my ($self, $msg, $includeScreenSeparator) = @_;
    
    my $stringUtil = StringUtil->new();
    my $formattedMsg = $stringUtil->fitToScreen($msg);
    
    if ($includeScreenSeparator)
    {
        print STDOUT "\n ------------------------------------------------------------------------------";
    }
    print STDOUT $formattedMsg ."\n";
}

###############################################################################
#
#    Subroutine
#        getUserInput
#
#    Description
#        Reads user input string.
#
sub getUserInput 
{
    my $ret;
    
    # read user input
    my $input = <STDIN>;
    
    # trim the new line from the input string
    chomp $input;
    
    # trim whitespace from the beginning and end of the input string
    my $stringUtil = StringUtil->new();
    $ret = $stringUtil->trimWhitespace($input);    
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        isRegexMatchingString
#
#    Description
#        Validates that the string conforms to the specified regex.
#
#    Return
#        1 if the string matches the regex
#        0 if the string does not match the regex
#
sub isRegexMatchingString
{
    my ($self, $string, $regex) = @_;
    my $ret = 0;
    
    my $logger = $self->logger;

    if ($string =~ m/^[$regex]+$/)
    {
        $ret = 1;
    }
    else
    {
        my $origString = $string;
        $string =~ s/[$regex]//g;
        $logger->traceError("String $origString does not conform to regex /^[$regex]+\$/. " .
            "Invalid characters: [$string]");
    }    
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        isValidPath
#
#    Description
#        Validates that the file or directory exists. Does not validate type.
#
#    Return
#        1 if the file/dir exists
#        0 if the file/dir does not exist
#
sub isValidPath
{
    my ($self, $path) = @_;
    my $ret = 0;
    
    my $logger = $self->logger;

    if (-e $path)
    {
        $ret = 1;
    }
    else
    {
        $logger->traceError("Path $path does not exist.");
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        isInValidRange
#
#    Description
#        Validates that an input value is in a specified range.
#
#    Return
#        1 if the input is in the range
#        0 if the input is outside the range
#
sub isInValidRange 
{
    my ($self, $input, $startRange, $endRange) = @_;
    my $ret = 0;
    
    my $logger = $self->logger;

    if ($input >= $startRange && $input <= $endRange)
    {
        $ret = 1;
    }
    else
    {
        $logger->traceError("Input $input is not in the specified range: $startRange-$endRange.");
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        isValidTrueFalse
#
#    Description
#        Validates that an input value is a true of false value.
#
#    Return
#        1 if the input is a true or false value
#        0 if the input is not a true or false value
#
sub isValidTrueFalse
{
    my ($self, $input) = @_;
    my $ret = 0;
    
    my $logger = $self->logger;

    if ($input =~ /y/i || $input =~ /yes/i || $input =~ /n/i || $input =~ /no/i ||
        $input =~ /t/i || $input =~ /true/i || $input =~ /f/i || $input =~ /false/i)
    {
        $ret = 1;
    }
    else
    {
        $logger->traceError("Input $input is not equivalent to 'true' or 'false.'");
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        isValidNumericChoice
#
#    Description
#        Validates that an input value is a numeric input that falls in the
#        specififed range.
#
#    Return
#        1 if the input matches the criteria
#        0 if the input is non-numeric or outside the valid range
#
sub isValidNumericChoice
{
    my ($self, $input, $startValue, $endValue) = @_;
    my $ret = 0;
    
    my $logger = $self->logger;
    
    if ($input !~ /^[0-9]+$/)
    {
        $logger->traceError("$input is an invalid numeric input.")
    }
    elsif ($input < $startValue || $input > $endValue)
    {
        $logger->traceError("$input is outside the valid input range of $startValue - $endValue");
    }
    else
    {
        $ret = 1;
    }
    
    return $ret;
}

1;