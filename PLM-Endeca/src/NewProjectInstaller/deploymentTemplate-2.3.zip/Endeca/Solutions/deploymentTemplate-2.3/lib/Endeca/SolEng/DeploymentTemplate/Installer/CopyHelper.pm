###############################################################################
###############################################################################
#
#                             COPY HELPER
#
#    This object exposes sbroutines used to copy files and directories.
#
###############################################################################
###############################################################################

package Endeca::SolEng::DeploymentTemplate::Installer::CopyHelper;

use strict;

use File::Spec;
use File::Copy;
use File::Glob qw(:glob);
use Endeca::SolEng::Util qw(Logger StringUtil);
use Endeca::SolEng::DeploymentTemplate::Installer::FileHelper;

###############################################################################
#
#    Constructor
#
#    Description
#        Constructor method for the CopyPattern object.
sub new
{
    my ($class) = @_;
    
    my $logger = Logger->new();
    $logger->scriptName("CopyHelper");
    
    my $self = {
        _logger => $logger,

    };
    
    bless $self, $class;
    return $self;
}

###############################################################################
#
#    Subroutine
#        logger
#
#    Description
#        Getter/setter for the logger field.
#
sub logger 
{
     my ($self, $logger) = @_;
     
     if ($logger)
     {
         $self->{_logger} = $logger;
     }
     
     return $self->{_logger};
}

###############################################################################
#
#    Subroutine
#        doCopy
#
#    Description
#        Performs the copy described in the specified CopyPattern object,
#        filtering files with the specified token map, if appropriate.
#
#    Return
#        1 if the copy complete successfully
#        0 if the copy failed
#
sub doCopy
{
    my ($self, $srcRootDir, $destRootDir, $copyPattern, $filterMapRef) = @_;
    
    my $logger = $self->logger;    
    my $ret = 0;
    
    if ($copyPattern && $srcRootDir && $destRootDir)
    {        
        my $srcDir = $copyPattern->srcDir;
        my $srcFile = $copyPattern->srcFile;
        if (! $srcFile)
        {
            $srcFile = "*";
        }
        my $destDir = $copyPattern->destDir;
        
        if ($srcDir && $srcFile && $destDir)
        {
            # make dirs absolute
            $srcDir = File::Spec->catdir($srcRootDir, $srcDir);
            $destDir = File::Spec->catdir($destRootDir, $destDir);
         
            my $fileHelper = Endeca::SolEng::DeploymentTemplate::Installer::FileHelper->new();
                    
            # validate that the copy dir and dest dir are both children of their
            # respective root dirs
            if (! $fileHelper->isChildDir($srcRootDir, $srcDir))
            {
                $logger->traceFatal("Invalid copy source dir $srcDir is not a child of root source dir $srcRootDir.");
            
            }
            elsif (! $fileHelper->isChildDir($destRootDir, $destDir))
            {
                $logger->traceFatal("Invalid copy dest dir $destDir is not a child of root dest dir $destRootDir.");
            }
            else
            {
                # clear the target directoy (and all subdirectories), if requested
                if ($copyPattern->clearDestDir && -d $destDir)
                {
                    if (! $fileHelper->removeDir($destDir) || ! $fileHelper->makePath($destDir))
                    {
                        $logger->traceError("Error clearing dest dir $destDir");
                    }
                }
                
                # get list of files that match the pattern
                my @files = $fileHelper->findFiles($srcDir, $srcFile, $copyPattern->recursive);
                
                # if no files match, log a message and return success
                if (! @files)
                {
                    my $logMsg = "No files matched ";
                    if ($copyPattern->recursive)
                    {
                        $logMsg .= "recursive ";
                    }
                    $logMsg .= "pattern '$srcFile' in source dir $srcDir.";
                    $logger->traceInfo($logMsg);
                    $ret = 1;
                }

                # for any files that do match, perform the copy
                foreach my $file (@files)
                {
                    my @splitFilePath = File::Spec->splitdir($file);
                    my $fileName = pop(@splitFilePath);
                    
                    # assume the file structure should be flattened
                    my $destFile = File::Spec->catfile($destDir, $fileName);
                    
                    # if sub directories should be preserved, create dest file using same relative path
                    if ($copyPattern->preserveSubDirs)
                    {
                        my $relFileName = File::Spec->abs2rel($file, $srcDir);
                        $destFile = File::Spec->catfile($destDir, $relFileName);
                    }
                    
                    # ensure the target directory exists
                    my @splitDestPath = File::Spec->splitdir($destFile);
                    pop(@splitDestPath);
                    my $targetDir = File::Spec->catdir(@splitDestPath);
                    if (! -d $targetDir)
                    {
                        $fileHelper->makePath($targetDir);
                    }
                    
                    if ($copyPattern->filterFiles)
                    {
                        if ($self->filterCopyFile($file, $destFile, $filterMapRef))
                        {
                            $ret = 1;
                            if ($copyPattern->mode)
                            {
                                $fileHelper->chmodFile($destFile, $copyPattern->mode);
                            }
                        }
                        else
                        {
                            $logger->traceError("Failed to filter copy $file to $destFile: $!");
                        }
                    }
                    else
                    {
                        if (copy($file, $destFile))
                        {
                            $ret = 1;
                            if ($copyPattern->mode)
                            {
                                $fileHelper->chmodFile($destFile, $copyPattern->mode);
                            }
                        }
                        else
                        {
                            $logger->traceError("Failed to copy $file to $destFile: $!");
                        }
                    }
                }
            }
        }
        else
        {
            $logger->traceError("Copy sub requires source and dest dirs.")
        }
    }
    else
    {
        $logger->traceError("Copy sub requires root source and root dest dirs, as well as a copy pattern.")
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        filterCopyFile
#
#    Description
#        Copies a file, filtering its content for tokens that match the
#        tokens in the specified filter map. The filename is also filtered
#        against the same list of tokens.
#
#    Return
#        1 if the copy completed successfully
#        0 if the copy failed
#
sub filterCopyFile
{
    my ($self, $srcFile, $destFile, $filterMapRef) = @_;
    
    my $logger = $self->logger;
    my $ret = 0;
    
    if ($srcFile && $destFile)
    {
        if ($filterMapRef)
        {
            # filter filename
            while ($destFile =~ /@@(.+?)@@/)
            {
                 my $varName = $1;
                 my $token = "@@" . $varName . "@@";
                 if (exists $filterMapRef->{$varName})
                 {
                     my $val = $filterMapRef->{$varName};
                     $destFile =~ s/$token/$val/;
                 }
                 else
                 {
                     $logger->traceWarn("Filename $srcFile contains unknown token $token. Token unchanged.");
                     last;
                 }
            }
            
            # copy file, replacing tokens as they're found
            if (open(SRCFILE, "<$srcFile") && open(DESTFILE, ">$destFile"))
            {
                while (<SRCFILE>) 
                {
                    my $line = $_;
                    
                    while ($line =~ /@@(.+?)@@/)
                    {
                        my $varName = $1;
                        my $token = "@@" . $varName . "@@";
                        if (exists $filterMapRef->{$varName})
                        {
                            my $val = $filterMapRef->{$varName};
                            $line =~ s/$token/$val/;
                        }
                        else
                        {
                            $logger->traceWarn("File $srcFile contains unknown token $token. Token unchanged.");
                            last;
                        }
                    }
             
                    print DESTFILE $line;
                }
                
                close(DESTFILE);
                close(SRCFILE);
                
                $ret = 1;
            }
            else
            {
                $logger->traceError("Failed to open file for filtered copying: $!");
            }
        }
        else
        {
            $logger->traceWarn("No tokens/filters specified to filter copy. Copying $srcFile to $destFile unfiltered.");
            if (copy($srcFile, $destFile))
            {
                $ret = 1;
            }
            else
            {
                $logger->traceError("Failed to copy $srcFile to $destFile: $!");
            }
        }
    }
    
    return $ret;
}


1;