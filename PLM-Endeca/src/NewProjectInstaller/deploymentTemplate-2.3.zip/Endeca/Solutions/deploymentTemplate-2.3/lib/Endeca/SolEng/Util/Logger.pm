###############################################################################
###############################################################################
#
#                                  LOGGER
#
#    This module exposes logging subroutines for use in other scripts.
#
###############################################################################
###############################################################################

package Endeca::SolEng::Util::Logger;

use strict;
use Endeca::SolEng::Util::StringUtil;

use constant StringUtil => "Endeca::SolEng::Util::StringUtil";

###############################################################################
#
#    Constructor
#
#    Description
#        Constructor method for the Logger object. Initializes null field values.
#
sub new
{
    my ($class) = @_;
    my $self = {
        _scriptName => undef
    };
    
    bless $self, $class;
    return $self;
}

###############################################################################
#
#    Subroutine
#        scriptName
#
#    Description
#        Getter/setter for the script name field.
#
sub scriptName 
{
     my ($self, $scriptName) = @_;
     
     if ($scriptName)
     {
         $self->{_scriptName} = $scriptName;
     }
     
     return $self->{_scriptName};
}

###############################################################################
#
#    Subroutine
#        traceOut, traceErr
#
#    Description
#        Prints a specified message string to standard output or standard error.
#
sub traceOut 
{
    my ($self, $msg) = @_;
    
    my $stringUtil = StringUtil->new();
    print STDOUT $stringUtil->fitToScreen(formattedTime() . " [" . $self->scriptName . "] " . $msg) . "\n";
}
sub traceErr 
{
    my ($self, $msg) = @_;
    
    my $stringUtil = StringUtil->new();
    print STDERR $stringUtil->fitToScreen(formattedTime() . " [" . $self->scriptName . "] " . $msg) . "\n";
}

###############################################################################
#
#    Subroutine
#        formattedTime
#
#    Description
#        Retrieves the current time and formats it for display.
#
sub formattedTime
{
    my $timeString;
    
    my ($year, $month, $day, $hours, $min, $sec) = (localtime)[5,4,3,2,1,0];
    my $YYYY = sprintf("%04d",$year+1900);
    my $MM = sprintf("%02d",$month+1);
    my $DD = sprintf("%02d",$day);
    my $hh = sprintf("%02d",$hours);
    my $mm = sprintf("%02d",$min);
    my $ss = sprintf("%02d",$sec);
    
    $timeString = $MM."/".$DD."/".$YYYY." ".$hh.":".$mm.":".$ss;
    
    return $timeString;
}

###############################################################################
#
#    Subroutine
#        traceInfo, traceWarn, traceError, traceFatal
#
#    Description
#        Print logging messages with varying severities to standard output
#        (INFO) or standard error (WARN, ERROR, FATAL). The traceFatal sub
#        causes the scriot to terminate after printing an error.
#
sub traceInfo 
{
    my ($self, $msg) = @_;
    $self->traceOut("INFO:  " . $msg);
}
sub traceWarn 
{
    my ($self, $msg) = @_;
    $self->traceErr("WARN:  " . $msg);
}
sub traceError 
{
    my ($self, $msg) = @_;
    $self->traceErr("ERROR: " . $msg);
}
sub traceFatal 
{
    my ($self, $msg) = @_;
    $self->traceErr("FATAL: " . $msg);
}

1;