###############################################################################
###############################################################################
#
#                              COPY PATTERN
#
#    This object is used to store information about an installer copy.
#
###############################################################################
###############################################################################

package Endeca::SolEng::DeploymentTemplate::Installer::CopyPattern;

use strict;

use Endeca::SolEng::Util qw(Logger StringUtil);

###############################################################################
#
#    Constructor
#
#    Description
#        Constructor method for the CopyPattern object.
sub new
{
    my ($class) = @_;
    
    my $logger = Logger->new();
    $logger->scriptName("CopyPattern");
    
    my $self = {
        _logger => $logger,
        _srcDir => undef,
        _srcFile => undef,
        _destDir => undef,
        _clearDestDir => 0,
        _recursive => 0,
        _preserveSubDirs => 0,
        _filterFiles => 0,
        _mode => undef,
        _primary => undef,
        _platform => undef,
        _endecaVersion => undef
    };
    
    bless $self, $class;
    return $self;
}

###############################################################################
#
#    Subroutine
#        logger
#
#    Description
#        Getter/setter for the logger field.
#
sub logger 
{
     my ($self, $logger) = @_;
     
     if ($logger)
     {
         $self->{_logger} = $logger;
     }
     
     return $self->{_logger};
}

###############################################################################
#
#    Subroutine
#        srcDir
#
#    Description
#        Getter/setter for the source directory field.
#
sub srcDir 
{
     my ($self, $srcDir) = @_;
     
     if ($srcDir)
     {
         $self->{_srcDir} = $srcDir;
     }
     
     return $self->{_srcDir};
}

###############################################################################
#
#    Subroutine
#        srcFile
#
#    Description
#        Getter/setter for the source file/pattern field.
#
sub srcFile 
{
     my ($self, $srcFile) = @_;
     
     if ($srcFile)
     {
         $self->{_srcFile} = $srcFile;
     }
     
     return $self->{_srcFile};
}

###############################################################################
#
#    Subroutine
#        destDir
#
#    Description
#        Getter/setter for the destination directory field.
#
sub destDir 
{
     my ($self, $destDir) = @_;
     
     if ($destDir)
     {
         $self->{_destDir} = $destDir;
     }
     
     return $self->{_destDir};
}

###############################################################################
#
#    Subroutine
#        clearDestDir
#
#    Description
#        Getter/setter for the clear destination directory field.
#
sub clearDestDir 
{
     my ($self, $clearDestDir) = @_;
     
     if ($clearDestDir)
     {
         $self->{_clearDestDir} = $clearDestDir;
     }
     
     return $self->{_clearDestDir};
}

###############################################################################
#
#    Subroutine
#        recursive
#
#    Description
#        Getter/setter for the recursive field.
#
sub recursive 
{
     my ($self, $recursive) = @_;
     
     if ($recursive)
     {
         $self->{_recursive} = $recursive;
     }
     
     return $self->{_recursive};
}

###############################################################################
#
#    Subroutine
#        preserveSubDirs
#
#    Description
#        Getter/setter for the preserve subdirectories field.
#
sub preserveSubDirs 
{
     my ($self, $preserveSubDirs) = @_;
     
     if ($preserveSubDirs)
     {
         $self->{_preserveSubDirs} = $preserveSubDirs;
     }
     
     return $self->{_preserveSubDirs};
}

###############################################################################
#
#    Subroutine
#        filterFiles
#
#    Description
#        Getter/setter for the filter files field.
#
sub filterFiles 
{
     my ($self, $filerFiles) = @_;
     
     if ($filerFiles)
     {
         $self->{_filterFiles} = $filerFiles;
     }
     
     return $self->{_filterFiles};
}

###############################################################################
#
#    Subroutine
#        primary
#
#    Description
#        Getter/setter for the primary field.
#
sub primary 
{
     my ($self, $primary) = @_;
     
     if ($primary)
     {
         $self->{_primary} = $primary;
     }
     
     return $self->{_primary};
}

###############################################################################
#
#    Subroutine
#        platform
#
#    Description
#        Getter/setter for the platform field.
#
sub platform 
{
     my ($self, $platform) = @_;
     
     if ($platform)
     {
         $self->{_platform} = $platform;
     }
     
     return $self->{_platform};
}

###############################################################################
#
#    Subroutine
#        endecaVersion
#
#    Description
#        Getter/setter for the IAP version field.
#
sub endecaVersion 
{
     my ($self, $endecaVersion) = @_;
     
     if ($endecaVersion)
     {
         $self->{_endecaVersion} = $endecaVersion;
     }
     
     return $self->{_endecaVersion};
}

###############################################################################
#
#    Subroutine
#        mode
#
#    Description
#        Getter/setter for the mode field.
#
sub mode 
{
     my ($self, $mode) = @_;
     
     if ($mode)
     {
         $self->{_mode} = $mode;
     }
     
     return $self->{_mode};
}

1;