###############################################################################
###############################################################################
#
#                             FILE HELPER
#
#    This object exposes sbroutines used to manipulate files and directories.
#
###############################################################################
###############################################################################

package Endeca::SolEng::DeploymentTemplate::Installer::FileHelper;

use strict;

use File::Spec;
use File::Copy;
use File::Glob qw(:glob);
use File::Path;
use Endeca::SolEng::Util qw(Logger StringUtil);

###############################################################################
#
#    Constructor
#
#    Description
#        Constructor method for the CopyPattern object.
sub new
{
    my ($class) = @_;
    
    my $logger = Logger->new();
    $logger->scriptName("FileHelper");
    
    my $self = {
        _logger => $logger,
    };
    
    bless $self, $class;
    return $self;
}

###############################################################################
#
#    Subroutine
#        logger
#
#    Description
#        Getter/setter for the logger field.
#
sub logger 
{
     my ($self, $logger) = @_;
     
     if ($logger)
     {
         $self->{_logger} = $logger;
     }
     
     return $self->{_logger};
}

###############################################################################
#
#    Subroutine
#        isChildDir
#
#    Description
#        Validates that one directory is the child of another.
#
#    Return
#        1 if the second directory is a child of the first
#        0 if the second directory is not a child of the first
#
sub isChildDir
{
    my ($self, $path1, $path2) = @_;
    
    my $logger = $self->logger;
    my $ret = 1;
    
    my @path1parts = File::Spec->splitdir($path1);
    my @path2parts = File::Spec->splitdir($path2);
    
    for (my $i = 0; $i < scalar(@path1parts); $i++)
    {
        if ($i >= scalar(@path2parts))
        {
            $ret = 0;
            last;
        }
        elsif($path1parts[$i] ne $path2parts[$i])
        {
            $ret = 0;
            last;
        }
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        archiveDir
#
#    Description
#        Archives the specified directory, renaming it to append a timestamp.
#
#    Return
#        1 if the directory was successfully archived
#        0 if archiving failed
#
sub archiveDir
{
    my ($self, $dir) = @_;
    
    my $ret = 0;
    my $logger = $self->logger;
    
    if (-d $dir)
    {
        my ($year, $month, $day, $hours, $min, $sec) = (localtime)[5,4,3,2,1,0];
        my $YYYY = sprintf("%04d",$year+1900);
        my $MM = sprintf("%02d",$month+1);
        my $DD = sprintf("%02d",$day);
        my $hh = sprintf("%02d",$hours);
        my $mm = sprintf("%02d",$min);
        my $ss = sprintf("%02d",$sec);
 
        my $timestamp = $YYYY."_".$MM."_".$DD."-".$hh."_".$mm."_".$ss;
        my $newDir = $dir.".".$timestamp.".bak";
        if (! rename($dir, $newDir))
        {
            $logger->traceError("Unable to rename $dir to $newDir: $!");
        }
        else
        {
            $logger->traceInfo("Renamed $dir to $newDir.");
            $ret = 1;
        }
    }
    else
    {
        $logger->traceError("Unable to rename $dir: not a valid directory");
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        removeDir
#
#    Description
#        Removes the specified directory and all files and subdirectories it
#        contains.
#
#    Return
#        1 if the directory was successfully removed
#        0 if removal failed
#
sub removeDir
{
    my ($self, $dir) = @_;
    my $ret = 1;
    
    my $logger = $self->logger;
    
    eval { rmtree($dir) };
    if ($@) 
    {
        $logger->traceError("Unable to remove dir $dir: $@");
        $ret = 0;
    }
    
    return $ret;    
}

###############################################################################
#
#    Subroutine
#        makePath
#
#    Description
#        Creates the specified directory, including all parent directories
#        that have not yet been created. If any of the directories already
#        exist, this sub will continue uninterrupted.
#
#    Return
#        1 path created successfully
#        0 path creation failed
#
sub makePath
{
    my ($self, $path) = @_;
    my $ret = 1;
    
    my $logger = $self->logger;
    
    eval { mkpath($path) };
    if ($@) 
    {
        $logger->traceError("Unable to create path $path: $@");
        $ret = 0;
    }
    
    return $ret;
}

sub chmodFile
{
    my ($self, $file, $modeStr) = @_;
    my $ret = 1;
    
    my $logger = $self->logger;

    if ($file && -f $file && $modeStr)
    {
        if ($modeStr !~ /^0?[0-7]{3}$/)
        {
           $logger->traceError("Invalid mode '$modeStr'. Valid mode strings must be three octal digits " .
               "with an optional leading zero (e.g. 755, 0644). Defaulting permissions.");
           $ret = 0;
        }
        else
        {
            my $mode = oct($modeStr);
            eval { chmod($mode, $file) };
            if ($@)
            {
                $logger->traceError("Unable to change permissions for $file to $modeStr: $@. Defaulting permissions.");
                $ret = 0;
            }
        }
    }
    
    return $ret;
}

###############################################################################
#
#    Subroutine
#        findFiles
#
#    Description
#        Returns a list of files in the specified directory that match
#        a pattern. If recursive is 1 (true), this sub will call itself
#        recursively, looking for the file pattern in subdirectories.
#
sub findFiles
{
    my ($self, $dir, $fileName, $recursive) = @_;
    
    my $logger = $self->logger;
    my @ret = ();
    
    if ($dir && -d $dir && $fileName)
    {
        my $file = File::Spec->catfile($dir, $fileName);
        my @matches = bsd_glob($file);
        
        foreach my $match (@matches)
        {
            if (-f $match)
            {
                push(@ret, $match);
            }
        }
        
        if ($recursive)
        {
            my $success = opendir(DIR, $dir); 
            if ($success) 
            {
                my @children = readdir(DIR);
                closedir(DIR);
                
                # strip out "." and ".." and the like
                @children = File::Spec->no_upwards(@children);
                
                foreach my $child (@children) 
                {
                    if ($child ne ".svn" && $child ne "CVS")
                    {
                        my $next = File::Spec->catdir($dir, $child);
                        
                        # If $next is a directory recursively call findFiles.
                        if (-d $next) 
                        {
                            push(@ret, $self->findFiles($next, $fileName, $recursive));
                        }
                    }
                }
            }
            
            if (! $success)
            {
                $logger->traceWarn("Failed to open $dir to look for files: $!");
            }
        }
    }
    
    return @ret;
}

1;