###############################################################################
###############################################################################
#
#                                INSTALLER
#
#    This module provides access to installer modules in the Installer 
#    package.
#
###############################################################################
###############################################################################

package Endeca::SolEng::DeploymentTemplate::Installer;

use strict;
use Endeca::SolEng::DeploymentTemplate::Installer::CopyPattern;
use Endeca::SolEng::DeploymentTemplate::Installer::CustomToken;
use Endeca::SolEng::DeploymentTemplate::Installer::CopyHelper;
use Endeca::SolEng::DeploymentTemplate::Installer::FileHelper;
use Endeca::SolEng::DeploymentTemplate::Installer::InputHelper;

require Exporter;
our @ISA = qw(Exporter);

use constant CopyPattern => 'Endeca::SolEng::DeploymentTemplate::Installer::CopyPattern';
use constant CustomToken => 'Endeca::SolEng::DeploymentTemplate::Installer::CustomToken';
use constant FileHelper => 'Endeca::SolEng::DeploymentTemplate::Installer::FileHelper';
use constant CopyHelper => 'Endeca::SolEng::DeploymentTemplate::Installer::CopyHelper';
use constant InputHelper => 'Endeca::SolEng::DeploymentTemplate::Installer::InputHelper';

our @EXPORT_OK =
(
    qw(CopyPattern CustomToken FileHelper CopyHelper InputHelper)
);

1;