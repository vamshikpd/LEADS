###############################################################################
###############################################################################
#
#                                 CONSTANTS
#
#    This module exposes constants used by other scripts/modules.
#
###############################################################################
###############################################################################

package Endeca::SolEng::DeploymentTemplate::Config::Constants;

use strict;
use File::Spec;
use FindBin;

require Exporter;
our @ISA = qw(Exporter);

# platform types
use constant PLATFORM_WINDOWS => "win";
use constant PLATFORM_UNIX    => "unix";

use constant IAP_460          => "460";
use constant IAP_470          => "470";
use constant IAP_480          => "480";
use constant IAP_500          => "500";
use constant IAP_510          => "510";

use constant DGRAPH_CI_APP_DESCRIPTOR => 
   File::Spec->catfile(File::Spec->catdir(File::Spec->catdir($FindBin::RealBin, File::Spec->updir), "conf"), "dgraph_ci_app_descriptor.xml");
use constant AGRAPH_CI_APP_DESCRIPTOR => 
   File::Spec->catfile(File::Spec->catdir(File::Spec->catdir($FindBin::RealBin, File::Spec->updir), "conf"), "agraph_ci_app_descriptor.xml");
use constant AGRAPH_PARALLEL_FORGE_CI_APP_DESCRIPTOR => 
   File::Spec->catfile(File::Spec->catdir(File::Spec->catdir($FindBin::RealBin, File::Spec->updir), "conf"), "agraph_parallel_forge_ci_app_descriptor.xml");
use constant DGRAPH_EAC_PERL_APP_DESCRIPTOR => 
   File::Spec->catfile(File::Spec->catdir(File::Spec->catdir($FindBin::RealBin, File::Spec->updir), "conf"), "dgraph_eac_perl_app_descriptor.xml");
use constant DGRAPH_EAC_JAVA_APP_DESCRIPTOR => 
   File::Spec->catfile(File::Spec->catdir(File::Spec->catdir($FindBin::RealBin, File::Spec->updir), "conf"), "dgraph_eac_java_app_descriptor.xml");
use constant AGRAPH_EAC_JAVA_APP_DESCRIPTOR => 
   File::Spec->catfile(File::Spec->catdir(File::Spec->catdir($FindBin::RealBin, File::Spec->updir), "conf"), "agraph_eac_java_app_descriptor.xml");
use constant AGRAPH_PARALLEL_FORGE_EAC_JAVA_APP_DESCRIPTOR => 
   File::Spec->catfile(File::Spec->catdir(File::Spec->catdir($FindBin::RealBin, File::Spec->updir), "conf"), "agraph_parallel_forge_eac_java_app_descriptor.xml");
   
# control system constants
use constant CONTROLLER_EAC_PERL => "eac-perl";
use constant CONTROLLER_EAC_JAVA => "eac-java";
use constant CONTROLLER_JCD      => "jcd";

our @EXPORT_OK = 
(
    qw(PLATFORM_WINDOWS PLATFORM_UNIX IAP_460 IAP_470 IAP_480 IAP_500 IAP_510
    DGRAPH_CI_APP_DESCRIPTOR DGRAPH_EAC_PERL_APP_DESCRIPTOR 
    DGRAPH_EAC_JAVA_APP_DESCRIPTOR AGRAPH_CI_APP_DESCRIPTOR 
    AGRAPH_PARALLEL_FORGE_CI_APP_DESCRIPTOR AGRAPH_EAC_JAVA_APP_DESCRIPTOR 
    AGRAPH_PARALLEL_FORGE_EAC_JAVA_APP_DESCRIPTOR CONTROLLER_EAC_PERL 
    CONTROLLER_EAC_JAVA CONTROLLER_JCD)
);

1;
