# Simple version of tee for use on Windows

open(FILEOUT, "> $ARGV[0]") || die("Can't open file $ARGV[0]\n");
while(<STDIN>)
{
	print STDOUT $_;
	print FILEOUT $_;
}
close FILEOUT;
