#!/usr/bin/perl
#
# Copyright (c) 2006 Endeca Technologies Inc. All rights reserved.
# COMPANY CONFIDENTIAL
#

use strict;
use File::Spec;


######################################################################
# Set the defaults.
#
my $crawlName;


######################################################################
# Parse the arguments.
#
my $arg = shift( @ARGV );
while( defined $arg ) {
  if( ! defined( $crawlName ) ) {
    $crawlName = $arg;
  }
  else {
    die "Too many arguments were specified.\n";
  }
  $arg = shift( @ARGV );
}


######################################################################
# Verify the crawl name.
#
die "You must specify a crawl name.\n"
  unless defined( $crawlName );

die "Illegal crawl name: ${crawlName}\n"
  unless $crawlName =~ /^\w+$/;


######################################################################
# Set and verify the template directory.
#
my $script = $0;

if( ! File::Spec->file_name_is_absolute( $script ) ) {
  $script = File::Spec->rel2abs( $script );
}

my @tempDirPath = File::Spec->splitdir( $script );
pop( @tempDirPath );
pop( @tempDirPath );
pop( @tempDirPath );
push( @tempDirPath, "crawl_script_templates" );
push( @tempDirPath, "\@CRAWL_NAME\@CasCrawlConfig.xml" );
my $template = File::Spec->catfile( @tempDirPath );

die "Crawl script template doesn't exist: ${template}\n"
  unless -f $template;


######################################################################
# Print some useful information about the crawl.
#
print "CRAWL_NAME = ${crawlName}\n";
print "TEMPLATE_DIR = ${template}\n";

######################################################################
# Filter copy crawl config file into script directory
#
my @destScriptPath = File::Spec->splitdir( $script );
pop( @destScriptPath );
pop( @destScriptPath );
pop( @destScriptPath );
push( @destScriptPath, "script" );
push( @destScriptPath, $crawlName . "CasCrawlConfig.xml" );
my $targetScriptFile = File::Spec->catfile( @destScriptPath );

filterCopy( $template, $targetScriptFile );


######################################################################
# Copies a single file:
#   - Applies a single CRAWL_NAME substitution filter.
#
sub filterCopy {
  my $srcFile = shift;
  my $destFile = shift;
  $destFile =~ s/\@CRAWL_NAME\@/$crawlName/g;
  
  my @destPath = File::Spec->splitdir( $destFile );
  my $relativeDestFile = $destPath[scalar @destPath - 1];
  print "  ${relativeDestFile}\n";
  
  open( SRCFILE, "<${srcFile}" ) or die( $! );
  open( DSTFILE, ">${destFile}" ) or die( $! );
  
  while ( <SRCFILE> ) {
    s/\@CRAWL_NAME\@/$crawlName/g;
    print DSTFILE $_;
  }
  
  close( DSTFILE );
  close( SRCFILE );
}
